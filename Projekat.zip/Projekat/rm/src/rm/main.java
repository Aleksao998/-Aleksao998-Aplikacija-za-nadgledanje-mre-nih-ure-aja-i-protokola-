package rm;
import java.io.IOException;

import com.ireasoning.protocol.*;
import com.ireasoning.protocol.snmp.*;
import rm.Gui;
public class main {

	public static void main(String[] args) throws IOException, SnmpEncodingException {
		new Gui();


	}

}
